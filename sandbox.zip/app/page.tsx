import MovieReservation from "./components/cinema";

export default function Home() {
  return (
    <main>
      <section>
        <MovieReservation></MovieReservation>
      </section>
    </main>
  );
}
